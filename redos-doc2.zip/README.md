# Demo Exam — sirius-exam.org

Ansible-автоматизация настройки стенда для демонстрационного экзамена.

## Структура проекта

```
.
├── ansible.cfg                  # Конфигурация Ansible
├── inventory/
│   ├── hosts.yml                # Инвентарь (хосты, пароли)
│   └── group_vars/all.yml       # Глобальные переменные
├── playbooks/
│   ├── 01-base.yml              # Базовая настройка (hostname, timezone, users, NTP)
│   ├── 02-network.yml           # Сеть (ISP NAT, Eltex interfaces/GRE/OSPF/NAT/DHCP)
│   ├── 03-ssh.yml               # SSH hardening (порт 2026, баннер, ограничения)
│   ├── 04-dns.yml               # DNS (BIND на HQ-SRV)
│   └── 05-services.yml          # Сервисы (RAID, NFS, Samba, Docker, Apache, Nginx)
├── site.yml                     # Мастер-плейбук (импортирует все)
├── isp.sh                       # Bootstrap-скрипт для ISP
├── requirements.yml             # Ansible Galaxy зависимости
├── ansible-playbooks/           # Eltex ESR collection
└── Задание.md                   # Текст задания
```

## Плейбуки и соответствие заданиям

| Плейбук | Задания | Описание |
|---------|---------|----------|
| `01-base.yml` | 1, 3c-g, 9d, Мод2-4 | Hostname (FQDN), timezone, SELinux, пользователи (sshuser, net_admin), NTP (chrony) |
| `02-network.yml` | 2, 3a-b, 4, 6, 7, 8 | ISP: NAT/forwarding/routes. Eltex: interfaces, GRE tunnel, OSPF, NAT, DHCP |
| `03-ssh.yml` | 5 | SSH: порт 2026, AllowUsers sshuser, MaxAuthTries 2, баннер |
| `04-dns.yml` | 9 | BIND DNS на HQ-SRV: прямая и обратные зоны, пересылка |
| `05-services.yml` | Мод2: 1-3, 5-6, 8-10 | RAID0, NFS, Samba, Docker testapp, Apache webapp, Nginx proxy, Browser |

## Быстрый старт

### 1. Подготовка ISP (запускается на ISP)

```bash
bash isp.sh
```

### 2. Запуск всего

```bash
ansible-playbook site.yml
```

### 3. Запуск отдельных плейбуков

```bash
# Только базовая настройка
ansible-playbook playbooks/01-base.yml

# Только сеть
ansible-playbook playbooks/02-network.yml

# Только SSH
ansible-playbook playbooks/03-ssh.yml

# Только DNS
ansible-playbook playbooks/04-dns.yml

# Только сервисы
ansible-playbook playbooks/05-services.yml
```

### 4. Запуск по тегам

```bash
# Только NTP
ansible-playbook playbooks/01-base.yml --tags ntp

# Только GRE туннель
ansible-playbook playbooks/02-network.yml --tags gre

# Только OSPF
ansible-playbook playbooks/02-network.yml --tags ospf

# Только Docker
ansible-playbook playbooks/05-services.yml --tags docker

# Только Samba
ansible-playbook playbooks/05-services.yml --tags samba

# Только Nginx proxy
ansible-playbook playbooks/05-services.yml --tags nginx
```

## Аутентификация

Ansible работает **по паролю** (SSH-ключи не используются):

- **Linux-хосты**: `root` / `P@ssw0rd` (через `sshpass`)
- **Eltex ESR**: `admin` / `P@ssw0rd` (через `network_cli`)
- ISP подключается локально (`ansible_connection: local`)

## Топология

```
                    ┌─────────┐
                    │   ISP   │ (NTP server, Nginx proxy)
                    │ RedOS   │
                    └────┬────┘
                 ┌───────┴───────┐
          172.16.1.0/28    172.16.2.0/28
                 │               │
           ┌─────┴─────┐  ┌─────┴─────┐
           │  HQ-RTR   │  │  BR-RTR   │
           │ Eltex ESR │  │ Eltex ESR │
           └─────┬─────┘  └─────┬─────┘
          ┌──────┼──────┐       │
   .100.0/27  .200.0/28  .99.0/29  .30.0/28
          │      │              │
     ┌────┴──┐ ┌─┴───┐    ┌────┴──┐
     │HQ-SRV │ │HQ-CLI│   │BR-SRV │
     │ RedOS │ │RedOS │   │ RedOS │
     └───────┘ └──────┘   └───────┘
```
